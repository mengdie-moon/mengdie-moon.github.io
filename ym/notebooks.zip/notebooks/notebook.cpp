#include "notebook.h"
#include <QMenuBar>
#include <QMenu>
#include <QAction>
#include <QPushButton>
#include <QTextStream>
#include <QPlainTextEdit>
#include <QHBoxLayout>
#include <QVBoxLayout>
#include <QShortcut>
#include <QKeySequence>
#include "about.h"
#include <QApplication>
#include <QDate>
#include <QDateTime>
#include <QFontDialog>
#include <QFileDialog>
#include <QMessageBox>
#include <QPalette>

NoteBook::NoteBook(QWidget *parent)
    : QMainWindow(parent)
{
    Init();
    setMaximumSize(800,700);
}

NoteBook::~NoteBook() {
}

void NoteBook::Init()
{

    QMenuBar *menuBar = new QMenuBar(this);

    QMenu *files = menuBar->addMenu("文件");
    QAction *open_file = new QAction("打开文件", this);
    open_file->setShortcut(QKeySequence("Ctrl+F"));

    QAction *save_file = new QAction("保存", this);
    save_file->setShortcut(QKeySequence("Ctrl+S"));

    QAction *css_file = new QAction("样式", this);
    css_file->setShortcut(QKeySequence("Ctrl+C+S"));
    Bold = new QAction(tr("加粗"), this);
    underline = new QAction(tr("下划线"), this);
    i = new QAction(tr("斜体"), this);
    black = new QAction(tr("黑色"), this);
    red = new QAction(tr("红色"), this);
    blue = new QAction(tr("蓝色"), this);
    QMenu *to_style = new QMenu(this);
    css_file->setMenu(to_style);
    to_style->addAction(Bold);
    to_style->addAction(underline);
    to_style->addAction(i);
    to_style->addAction(black);
    to_style->addAction(red);
    to_style->addAction(blue);

    QAction *close_file = new QAction("退出", this);
    close_file->setShortcut(QKeySequence("Esc"));

    files->addAction(open_file);
    files->addAction(save_file);
    files->addAction(css_file);
    files->addAction(close_file);

    QMenu *writer = menuBar->addMenu("编辑");
    QAction *pen_style = new QAction("字体", this);
    pen_style->setShortcut(QKeySequence("Ctrl+P"));
    //隶属于pen_style
    pen_style_YaHei = new QAction(tr("微软雅黑"), this);
    pen_style_KAITI = new QAction(tr("楷体"), this);
    pen_style_Consolas = new QAction(tr("Consolas"), this);
    pen_style_more = new QAction(tr("更多字体"), this);

    writer->addAction(pen_style);

    pen_style_YaHei->setFont(QFont("微软雅黑"));
    pen_style_KAITI->setFont(QFont("楷体"));
    pen_style_Consolas->setFont(QFont("Consolas"));

    QMenu *fontMenu = new QMenu(this);
    pen_style->setMenu(fontMenu);
    fontMenu->addAction(pen_style_YaHei);
    fontMenu->addAction(pen_style_KAITI);
    fontMenu->addAction(pen_style_Consolas);
    fontMenu->addAction(pen_style_more);

    fontMenu->addAction(pen_style_YaHei);
    pen_style->setMenu(fontMenu);

    QAction *clear_file = new QAction("清空", this);
    clear_file->setShortcut(QKeySequence("Ctrl+Alt+C"));

    QAction *times = new QAction("日期", this);
    times->setShortcut(QKeySequence("Ctrl+D"));

    writer->addAction(pen_style);
    writer->addAction(clear_file);
    writer->addAction(times);

    QMenu *more = menuBar->addMenu("更多");
    QAction *about = new QAction("关于制作", this);
    // QShortcut *s_about = new QShortcut(QKeySequence("Ctrl+O"), this);   //已弃用
    about->setShortcut(QKeySequence("Ctrl+O"));

    more->addAction(about);

    QVBoxLayout *vbox = new QVBoxLayout(this);
    QWidget *centralWidget = new QWidget(this); // 创建中心部件
    centralWidget->setLayout(vbox);
    textEdit = new QPlainTextEdit(centralWidget);
    textEdit->setPlainText(tr("米哈游牌记事本"));
    textEdit->setStyleSheet("margin:0; padding:0;");

    this->setMenuBar(menuBar);

    QHBoxLayout *hbox = new QHBoxLayout(this);
    hbox->addWidget(textEdit);
    vbox->addLayout(hbox);
    this->setLayout(vbox);
    this->setCentralWidget(centralWidget);

    //槽函数绑定区域
    connect(close_file, &QAction::triggered, this, &NoteBook::close);//关闭文件
    connect(about, &QAction::triggered, this, &NoteBook::abouts);//关于我们
    connect(clear_file, &QAction::triggered, static_cast<QObject*>(this), [=] () {
        textEdit->clear();
    });
    connect(times, &QAction::triggered, static_cast<QObject*>(this), [=] () {
        QDateTime dataTime = QDateTime::currentDateTime();
        QString s_times = dataTime.toString(Qt::ISODate);//格式化输出时间
        QString strs = textEdit->toPlainText();
        textEdit->setPlainText(strs+"\n"+s_times);
    });//日期
    connect(pen_style_YaHei, &QAction::triggered, static_cast<QObject*>(this), [this] () {
        QFont YAHEI = QFont("微软雅黑");
        this->textEdit->setFont(YAHEI);
    });
    connect(pen_style_KAITI, &QAction::triggered, static_cast<QObject*>(this), [this] () {
        QFont KAITI = QFont("楷体");
        this->textEdit->setFont(KAITI);
    });
    connect(pen_style_Consolas, &QAction::triggered, static_cast<QObject*>(this), [this] () {
        QFont Consolas = QFont("Consolas");
        this->textEdit->setFont(Consolas);
    });
    connect(pen_style_more, &QAction::triggered, static_cast<QObject*>(this), [this] () {
        bool ok;
        QFont fonts_more = QFontDialog::getFont(&ok, this);
        this->textEdit->setFont(fonts_more);
    });
    connect(Bold, &QAction::triggered, static_cast<QObject*>(this), [this] () {
        QFont fonts = textEdit->font();
        bool ok = fonts.bold();
        if(ok){
            fonts.setBold(false);
        }else{
            fonts.setBold(true);
        }
        this->textEdit->setFont(fonts);
    });
    connect(i, &QAction::triggered, static_cast<QObject*>(this), [this] () {
        QFont fonts = textEdit->font();
        bool ok = fonts.italic();
        if(ok){
            fonts.setItalic(false);
        }else{
            fonts.setItalic(true);
        }
        this->textEdit->setFont(fonts);
    });
    connect(underline, &QAction::triggered, static_cast<QObject*>(this), [this] () {
        QFont fonts = textEdit->font();
        bool ok = fonts.underline();
        if(ok){
            fonts.setUnderline(false);
        }else{
            fonts.setUnderline(true);
        }
        this->textEdit->setFont(fonts);
    });
    connect(black, &QAction::triggered, static_cast<QObject*>(this), [this] () {
        QPalette pal = textEdit->palette();
        pal.setColor(QPalette::Text, Qt::black);
        textEdit->setPalette(pal);
    });
    connect(blue, &QAction::triggered, static_cast<QObject*>(this), [this] () {
        QPalette pal = textEdit->palette();
        pal.setColor(QPalette::Text, Qt::blue);
        textEdit->setPalette(pal);
    });
    connect(red, &QAction::triggered, static_cast<QObject*>(this), [this] () {
        QPalette pal = textEdit->palette();
        pal.setColor(QPalette::Text, Qt::red);
        textEdit->setPalette(pal);
    });
    connect(open_file, &QAction::triggered, this, &NoteBook::open_files);
    connect(save_file, &QAction::triggered, this, &NoteBook::save_files);
}

void NoteBook::abouts(){
    about *ab = new about;
    ab->show();
}
//文件操作勿动  程序未响应不负责!!
void NoteBook::open_files()
{
    QString f("所有(*.*);;文件(*.txt);;源码(*.h *.cpp *.c *.py *.html *.css *.js)");
    QString s = QFileDialog::getOpenFileName(this, f);
    QFile file(s);
    if(!file.open(QIODevice::ReadOnly)){
        QMessageBox::warning(this, "警告", "打开文件失败");
        return;
    }
    QTextDocument *dos = textEdit->document();//dos代替textEdit操作
    dos->clear();
    QByteArray data = file.readAll();//读取全部
    file.close();
    dos->setPlainText(data);

    file.close();
}

void NoteBook::save_files()
{
    QString f("所有(*.*);;文件(*.txt);;源码(*.h *.cpp *.c *.py *.html *.css *.js)");
    QString s = QFileDialog::getSaveFileName(this, f);
    if(s.isEmpty()){
        return;
    }
    QFile file(s);
    //只写与清空原本文件
    if(!file.open(QIODevice::WriteOnly | QIODevice::Truncate)){
        QMessageBox::warning(this, "警告", "打开文件失败");
        return;
    }
    file.write(textEdit->document()->toPlainText().toStdString().c_str());//获取内容->纯文本->标准文本->c风格字符串
    file.close();
}
