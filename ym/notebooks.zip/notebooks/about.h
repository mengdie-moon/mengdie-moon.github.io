#ifndef ABOUT_H
#define ABOUT_H

#include <QWidget>

class about : public QWidget
{
    Q_OBJECT
public:
    explicit about(QWidget *parent = nullptr);
private:
    void Init_About();
private slots:
    void FH_tos();
signals:
};

#endif // ABOUT_H
