#ifndef NOTEBOOK_H
#define NOTEBOOK_H

#include <QMainWindow>
class QPlainTextEdit;
class QAction;
class NoteBook : public QMainWindow
{
    Q_OBJECT

public:
    NoteBook(QWidget *parent = nullptr);
    ~NoteBook();
private:
    QPlainTextEdit *textEdit;
    QAction *pen_style_YaHei;
    QAction *pen_style_KAITI;
    QAction *pen_style_Consolas;
    QAction *pen_style_more;

    QAction *Bold;
    QAction *underline;
    QAction *i;//斜体 这里借鉴html<i>
    QAction *black;
    QAction *blue;
    QAction *red;
private:
    void Init();
private slots:
    void abouts();
    void open_files();
    void save_files();
};
#endif // NOTEBOOK_H
