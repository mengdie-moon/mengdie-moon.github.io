#include "notebook.h"

#include <QApplication>

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    NoteBook w;
    w.setWindowTitle("记事本--梦蝶");
    w.setWindowIcon(QIcon(":/icon/icon.png"));
    w.show();
    return a.exec();
}
