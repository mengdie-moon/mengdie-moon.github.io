#include "about.h"
// #include "notebook.h"
#include <QHBoxLayout>//水平布局
#include <QVBoxLayout>//垂直布局
#include <QPushButton>
#include <QLabel>
#include <QDesktopServices>


about::about(QWidget *parent)
    : QWidget{parent}
{
    setMaximumSize(300, 220);
    setWindowTitle("记事本--About");
    setWindowIcon(QIcon(":/icon/icon.png"));
    Init_About();
}

void about::Init_About()
{
    QLabel *writer = new QLabel("作者: 梦蝶 制作语言:C++ 框架:Qt6", this);
    QHBoxLayout *hbox = new QHBoxLayout;
    hbox->addWidget(writer);
    writer->setWordWrap(true);

    QString Inc = "本代码有许多变量名称取名并不合理(都怪原神)"
                  "使用教程请看--><使用教程.html>"
                  "双击即可浏览器打开查看";
    QLabel *Includece = new QLabel(Inc, this);
    QHBoxLayout *hbox2 = new QHBoxLayout;
    hbox2->addWidget(Includece);
    Includece->setWordWrap(true);

    QString Add = "加入我们这个小白群体,裙号->597569159";
    QLabel *add_we = new QLabel(Add, this);
    QHBoxLayout *hbox3 = new QHBoxLayout;
    hbox3->addWidget(add_we);
    add_we->setWordWrap(true);

    QPushButton *url = new QPushButton("传送门", this);
    url->setCursor(QCursor(Qt::PointingHandCursor));
    url->setStyleSheet("border-style: none; color: blue; background-color: transparent; padding:0;");
    url->resize(10,5);
    hbox3->setSpacing(5);
    hbox3->addWidget(url);

    QPushButton *FH = new QPushButton("返回", this);
    QHBoxLayout *hbox4 = new QHBoxLayout;
    hbox4->addWidget(FH);

    QVBoxLayout *vbox = new QVBoxLayout;
    vbox->addLayout(hbox);
    vbox->addLayout(hbox2);
    vbox->addLayout(hbox3);
    vbox->addLayout(hbox4);

    setLayout(vbox);
    connect(url, &QPushButton::clicked, [](){
        QDesktopServices::openUrl(QUrl("https://qm.qq.com/q/YBh0XKQn4e"));
    });//没有转跳成功刷新一下试试
    connect(FH, SIGNAL(clicked(bool)), this, SLOT(FH_tos()));
}

void about::FH_tos()
{
    this->close();
    // NoteBook *note = new NoteBook(this);
    // note->show();
    if(parentWidget()){
        parentWidget()->setFocus();
    }
}
