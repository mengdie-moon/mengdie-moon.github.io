import requests
from lxml import etree
class Yan:
    title_url = 'https://xiaoao.5000yan.com/'
    # 42208
    base_url = 'https://xiaoao.5000yan.com/{}.html'
    headers = {
        "user-agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/127.0.0.0 Safari/537.36 Edg/127.0.0.0"
    }
    def __init__(self):
        self.url_list = []
        for i in range(42208, 42249):
            newurl = self.base_url.format(i)
            self.url_list.append(newurl)
    def title_Yan(self):
        titles_list = []
        page_list = []
        response = requests.get(url=self.title_url, headers=self.headers)
        html = etree.HTML(response.content.decode())
        datalist = html.xpath("//ul/li[@class='p-2']")
        for li in datalist:
            titles = li.xpath("./a/text()")
            titles_list.append(titles[0])
        for i, url in enumerate(self.url_list):
            print("正在保存->", titles_list[i])
            response = requests.get(url=url, headers=self.headers)
            response.raise_for_status()
            html = etree.HTML(response.content.decode())
            page = html.xpath("//div[@class='grap']/p/text()")
            text = "".join(page).replace(" ", "_")  # 替换空格 坑死我了
            with open(f"{titles_list[i]}.txt", 'w', encoding='utf-8') as f:
                f.write(text)
if __name__ == '__main__':
    yan = Yan()
    yan.title_Yan()
