#include "dialog.h"

#include <QApplication>

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    Dialog w;
    w.setWindowTitle("Students--login");
    w.setWindowIcon(QIcon(":/icons/C:/Users/admin/Pictures/c.jpg"));
    w.setMaximumSize(250, 150);
    w.show();
    return a.exec();
}
