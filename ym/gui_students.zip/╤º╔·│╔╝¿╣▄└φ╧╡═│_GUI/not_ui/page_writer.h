#ifndef PAGE_WRITER_H
#define PAGE_WRITER_H

#include <QWidget>

class QLabel;
class QLineEdit;
class QPushButton;
class QCheckBox;
class QRadioButton;
class QPlainTextEdit;

class Page_writer : public QWidget
{
    Q_OBJECT
public:
    explicit Page_writer(QWidget *parent = nullptr);

private:
    QLabel *style;
    QCheckBox *Underline;
    QCheckBox *I_text;
    QCheckBox *Bold;

    QLabel *Color;
    QRadioButton *black;
    QRadioButton *blue;
    QRadioButton *red;
    QRadioButton *darkblue;

    QPlainTextEdit *Writer;

    QPushButton *Clear;
    QPushButton *Save;
    QPushButton *Return;
    QPushButton *Close;
protected slots:
    void clear_text();
    void returns();
    void Saves();

    void under_line(bool YN);
    void I_texts(bool YN);
    void bold(bool YN);
    void Colors();
signals:
};

#endif // PAGE_WRITER_H
