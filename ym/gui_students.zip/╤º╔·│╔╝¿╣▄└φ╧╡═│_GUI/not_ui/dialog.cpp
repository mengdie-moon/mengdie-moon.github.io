#include "dialog.h"
#include "s_mainwin.h"
#include <QHBoxLayout>//水平布局
#include <QVBoxLayout>//垂直布局
#include <QPushButton>
#include <QMessageBox>
#include <QCheckBox>
#include <QRadioButton>
#include <QPlainTextEdit>
#include <QLabel>
#include <QLineEdit>
#include <QCheckBox>

void Dialog::login()
{
    QString user = UserInput->text();
    QString Pass = PassworldInput->text();
    if((user == "admin"&&Pass == "123456")&&(Litter->isChecked())){
        qDebug()<< "登录成功";
        QMessageBox::information(this, QString("祝贺"), "欢迎管理员登录成功!");
        this->reject();
        s_mainWin *mainWin_s = new s_mainWin;
        mainWin_s->show();
    }else if(!Litter->isChecked()){
        QMessageBox::warning(this, QString("警告"), "未阅读用户协议 不予通过");
    }else if((user == "" && Pass == "") || (user == "" && Pass != "") || (user != "" && Pass == "")){
        qDebug()<< "登录失败";
        QMessageBox::warning(this, QString("警告"), "请输入完整");
    }else if(user != "admin" || Pass != "123456"){
        qDebug()<< "验证失败";
        QMessageBox::warning(this, QString("警告"), "验证失败 账号或密码错误");
    }
}

class TermsDialog : public QDialog {
    QTextEdit *termsText;
public:
    QString html="我们这里是基于原神用派蒙打造的学生管理系统  版权归梦蝶所有 禁止加入非法内容 版权归梦蝶所有\n以下是一些寄语"
                   "原神....是米哈游打造的3D开放世界冒险类游戏";
    TermsDialog(QWidget *parent = nullptr) : QDialog(parent) {
        termsText = new QTextEdit(this);
        termsText->setStyleSheet("border-style: none; background-color: transparent; padding:0;");
        termsText->setReadOnly(true);//只读
        termsText->setHtml(html);
        QVBoxLayout *layout = new QVBoxLayout(this);
        layout->addWidget(termsText);
        setWindowTitle("梦蝶--用户协议");
    }
};

Dialog::Dialog(QWidget *parent)
    : QDialog(parent)
{
    User = new QLabel("账号: ", this);
    UserInput = new QLineEdit(this);

    QHBoxLayout *hbox = new QHBoxLayout;
    hbox->addWidget(User);
    hbox->addWidget(UserInput);

    Passworld = new QLabel("密码: ", this);
    PassworldInput = new QLineEdit(this);
    PassworldInput->setEchoMode(QLineEdit::Password);
    QHBoxLayout *hbox2 = new QHBoxLayout;
    hbox2->addWidget(Passworld);
    hbox2->addWidget(PassworldInput);

    Litter = new QCheckBox("我已经阅读并同意", this);
    termbutton = new QPushButton("用户协议", this);
    termbutton->setCursor(QCursor(Qt::PointingHandCursor));
    termbutton->setStyleSheet("border-style: none; color: blue; background-color: transparent; padding:0;");
    QHBoxLayout *hboxs = new QHBoxLayout;
    hboxs->addWidget(Litter);
    hboxs->addWidget(termbutton);

    Login = new QPushButton("登录", this);
    Close = new QPushButton("退出", this);
    QHBoxLayout *hbox3 = new QHBoxLayout;
    hbox3->addWidget(Login);
    hbox3->addWidget(Close);

    QVBoxLayout *vbox = new QVBoxLayout;
    vbox->addLayout(hbox);
    vbox->addLayout(hbox2);
    vbox->addLayout(hboxs);
    vbox->addLayout(hbox3);
    setLayout(vbox);

    connect(Close, SIGNAL(clicked(bool)), this, SLOT(close()));
    connect(Login, SIGNAL(clicked(bool)), this, SLOT(login()));
    connect(termbutton, &QPushButton::clicked, [this]() {
        TermsDialog *dialog = new TermsDialog(this);
        dialog->exec();//造成程序堵塞
    });
}

Dialog::~Dialog() {

}
