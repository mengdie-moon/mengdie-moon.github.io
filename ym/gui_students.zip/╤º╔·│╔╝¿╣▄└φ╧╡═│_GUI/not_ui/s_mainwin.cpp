#include "s_mainwin.h"
#include "about.h"
#include "page_writer.h"
#include "main_s.h"
#include <QHBoxLayout>//水平布局
#include <QVBoxLayout>//垂直布局
#include <QPushButton>

s_mainWin::s_mainWin(QWidget *parent)
    : QWidget{parent}
{
    setWindowTitle("Students--选择");
    setWindowIcon(QIcon(":/icons/C:/Users/admin/Pictures/c.jpg"));
    setMaximumSize(200, 50);

    Texts_s = new QPushButton("学生信息", this);
    Writer_s = new QPushButton("文本编辑", this);
    Includece_s = new QPushButton("关于我们", this);
    QHBoxLayout *hbox = new QHBoxLayout;
    hbox->addWidget(Texts_s); hbox->addWidget(Writer_s); hbox->addWidget(Includece_s);
    QVBoxLayout *vbox = new QVBoxLayout;
    vbox->addLayout(hbox);
    connect(Includece_s, SIGNAL(clicked(bool)), this, SLOT(show_about()));
    connect(Writer_s, SIGNAL(clicked(bool)), this, SLOT(show_writer()));
    connect(Texts_s, SIGNAL(clicked(bool)), this, SLOT(show_main()));
    setLayout(vbox);
}

void s_mainWin::show_about()
{
    this->close();
    About *about = new About;
    about->show();
    qDebug()<< "目标 关于我们 打开成功";
}

void s_mainWin::show_writer()
{
    this->close();
    Page_writer *writer = new Page_writer;
    writer->show();
    qDebug()<< "目标 文本编辑 打开成功";
}

void s_mainWin::show_main()
{
    this->close();
    main_s *main = new main_s;
    main->show();
    qDebug()<< "目标 学生信息 打开成功";
}

