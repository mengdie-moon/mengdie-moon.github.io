#ifndef MAIN_S_H
#define MAIN_S_H

#include <QWidget>

class QTableView;
class QPushButton;
class QLabel;

class main_s : public QWidget
{
    Q_OBJECT
public:
    explicit main_s(QWidget *parent = nullptr);

private:
    QLabel *Eg;
    QLabel *Eg2;
    QTableView *table;

    QPushButton *Read;
    QPushButton *Add;
    QPushButton *Save;
    QPushButton *Clear;
    QPushButton *Delete;
    QPushButton *Return;
    QPushButton *Close;
protected slots:
    void returns();
    void ReadFileData();
    void clears();
    void saves();
    void add();
    void deletes();
signals:
};

#endif // MAIN_S_H
