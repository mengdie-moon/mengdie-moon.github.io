#include "page_writer.h"
#include "s_mainwin.h"
#include <QHBoxLayout>//水平布局
#include <QVBoxLayout>//垂直布局
#include <QPushButton>
#include <QRadioButton>
#include <QPlainTextEdit>
#include <QLabel>
#include <QCheckBox>
#include <QFileDialog>

Page_writer::Page_writer(QWidget *parent)
    : QWidget{parent}
{
    setWindowTitle("Students--Writer");
    setWindowIcon(QIcon(":/icons/C:/Users/admin/Pictures/c.jpg"));

    style = new QLabel("样式", this);
    QHBoxLayout *hbox1 = new QHBoxLayout;
    hbox1->addWidget(style);
    Underline = new QCheckBox("下划线", this);
    I_text = new QCheckBox("斜体", this);
    Bold = new QCheckBox("加粗", this);
    QHBoxLayout *hbox2 = new QHBoxLayout;
    hbox2->addWidget(Underline);
    hbox2->addWidget(I_text);
    hbox2->addWidget(Bold);

    Color = new QLabel("颜色", this);
    QHBoxLayout *hbox5 = new QHBoxLayout; hbox5->addWidget(Color);
    black = new QRadioButton("黑色", this); black->setChecked(true);
    blue = new QRadioButton("蓝色", this);
    red = new QRadioButton("红色", this);
    darkblue = new QRadioButton("暗蓝色", this);
    QHBoxLayout *hbox6 = new QHBoxLayout;
    hbox6->addWidget(black); hbox6->addWidget(blue); hbox6->addWidget(red); hbox6->addWidget(darkblue);

    Writer = new QPlainTextEdit("梦蝶我爱你", this);
    Clear = new QPushButton("清空", this);
    Save = new QPushButton("保存", this);
    Return = new QPushButton("返回", this);
    Close = new QPushButton("退出", this);
    QHBoxLayout *hbox7 = new QHBoxLayout;
    hbox7->addWidget(Clear); hbox7->addWidget(Save); hbox7->addWidget(Return); hbox7->addWidget(Close);

    QVBoxLayout *vbox = new QVBoxLayout;
    vbox->addLayout(hbox1); vbox->addLayout(hbox2);  vbox->addLayout(hbox5); vbox->addLayout(hbox6);
    vbox->addWidget(Writer); vbox->addLayout(hbox7);

    setLayout(vbox);
    //4个PushButton槽函数
    connect(Close, SIGNAL(clicked(bool)), this, SLOT(close()));
    connect(Clear, SIGNAL(clicked(bool)), this, SLOT(clear_text()));
    connect(Return, SIGNAL(clicked(bool)), this, SLOT(returns()));
    connect(Save, SIGNAL(clicked(bool)), this, SLOT(Saves()));
    //3个CheckButton槽函数
    connect(Underline, SIGNAL(clicked(bool)), this, SLOT(under_line(bool)));
    connect(I_text, SIGNAL(clicked(bool)), this, SLOT(I_texts(bool)));
    connect(Bold, SIGNAL(clicked(bool)), this, SLOT(bold(bool)));
    //4个RadioBUtton槽函数
    connect(black, SIGNAL(clicked(bool)), this, SLOT(Colors()));
    connect(blue, SIGNAL(clicked(bool)), this, SLOT(Colors()));
    connect(red, SIGNAL(clicked(bool)), this, SLOT(Colors()));
    connect(darkblue, SIGNAL(clicked(bool)), this, SLOT(Colors()));
}

void Page_writer::clear_text()
{
    Writer->clear();
}

void Page_writer::returns()
{
    this->close();
    s_mainWin *returns = new s_mainWin;
    returns->show();
}

void Page_writer::Saves()
{
    QString fileName = QFileDialog::getSaveFileName(nullptr, "保存文件", "", "文本文件 (*.txt);;所有文件 (*.*)");
    if (!fileName.isEmpty()) {
        // 打开文件准备写入
        QFile file(fileName);
        if (file.open(QIODevice::WriteOnly | QIODevice::Text)) {
            QTextStream out(&file);
            // 将QTextEdit的内容写入文件
            out << Writer->toPlainText();
            file.close();
        }
    }
}

void Page_writer::under_line(bool YN)
{
    QFont fonts = Writer->font();
    fonts.setUnderline(YN);
    Writer->setFont(fonts);
}

void Page_writer::I_texts(bool YN)
{
    QFont fonts = Writer->font();
    fonts.setItalic(YN);
    Writer->setFont(fonts);
}

void Page_writer::bold(bool YN)
{
    QFont fonts = Writer->font();
    fonts.setBold(YN);
    Writer->setFont(fonts);
}

void Page_writer::Colors()
{
    QPalette palettes = Writer->palette();
    if(black->isChecked()){
        palettes.setColor(QPalette::Text, Qt::black);
    }else if(blue->isChecked()){
        palettes.setColor(QPalette::Text, Qt::blue);
    }else if(red->isChecked()){
        palettes.setColor(QPalette::Text, Qt::red);
    }else if(darkblue->isChecked()){
        palettes.setColor(QPalette::Text, Qt::darkBlue);
    }
    Writer->setPalette(palettes);
}
