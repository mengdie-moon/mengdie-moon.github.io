#include "about.h"
#include "s_mainwin.h"
#include <QHBoxLayout>//水平布局
#include <QVBoxLayout>//垂直布局
#include <QPushButton>
#include <QLabel>
#include <QDesktopServices>

About::About(QWidget *parent)
    : QWidget{parent}
{
    setWindowTitle("About");
    setWindowIcon(QIcon(":/icons/C:/Users/admin/Pictures/c.jpg"));
    setMaximumSize(250, 170);

    writer = new QLabel("作者: 梦蝶", this);
    QHBoxLayout *hbox = new QHBoxLayout;
    hbox->addWidget(writer);
    writer->setWordWrap(true);

    QString Inc = "本代码有许多变量名称取名并不合理(奈何我只有这么点文化了)"
                  "但是问题不大 我还是把这个死磕出来了 b站等各大平台肯定也有教学"
                  "但是我想说这个是由我独自一个人写的绝对没有看着视频写!!";
    Includece = new QLabel(Inc, this);
    QHBoxLayout *hbox2 = new QHBoxLayout;
    hbox2->addWidget(Includece);
    Includece->setWordWrap(true);

    QString Add = "加入我们这个小白群体,裙号->597569159";
    add_we = new QLabel(Add, this);
    QHBoxLayout *hbox3 = new QHBoxLayout;
    hbox3->addWidget(add_we);
    add_we->setWordWrap(true);

    url = new QPushButton("传送门", this);
    url->setCursor(QCursor(Qt::PointingHandCursor));
    url->setStyleSheet("border-style: none; color: blue; background-color: transparent; padding:0;");
    url->resize(10,5);
    hbox3->setSpacing(5);
    hbox3->addWidget(url);

    FH = new QPushButton("返回", this);
    QHBoxLayout *hbox4 = new QHBoxLayout;
    hbox4->addWidget(FH);

    QVBoxLayout *vbox = new QVBoxLayout;
    vbox->addLayout(hbox);
    vbox->addLayout(hbox2);
    vbox->addLayout(hbox3);
    vbox->addLayout(hbox4);

    setLayout(vbox);
    connect(url, &QPushButton::clicked, [this](){
        QDesktopServices::openUrl(QUrl("http://qm.qq.com/cgi-bin/qm/qr?_wv=1027&k=giagaLz_uMF1LapBepWR0KrcnbZhINJ9&authKey=fowrccPCya%2BuYQQNNEJsZnROD77QTbGjZDrAM08RRTxcQZ%2ByGjLmUaIR%2FNYg1gRm&noverify=0&group_code=597569159"));
    });//没有转跳成功刷新一下试试
    connect(FH, SIGNAL(clicked(bool)), this, SLOT(FH_tos()));
}

void About::FH_tos()
{
    this->close();
    s_mainWin *fh = new s_mainWin;
    fh->show();
    qDebug()<< "返回成功";
}
