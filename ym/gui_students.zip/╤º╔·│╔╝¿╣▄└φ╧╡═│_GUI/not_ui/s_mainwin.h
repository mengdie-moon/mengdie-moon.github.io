#ifndef S_MAINWIN_H
#define S_MAINWIN_H
#include "dialog.h"

class QPushButton;
class QGroupBox;

class s_mainWin : public QWidget
{
    Q_OBJECT
public:
    explicit s_mainWin(QWidget *parent = nullptr);

protected slots:
    void show_about();
    void show_writer();
    void show_main();
private:
    QGroupBox *menu;
    QPushButton *Texts_s;
    QPushButton *Writer_s;
    QPushButton *Includece_s;
signals:
};

#endif // S_MAINWIN_H
