#include "main_s.h"
#include "s_mainwin.h"
#include <QHBoxLayout>//水平布局
#include <QVBoxLayout>//垂直布局
#include <QPushButton>
#include <QMessageBox>
#include <QCheckBox>
#include <QRadioButton>
#include <QPlainTextEdit>
#include <QLabel>
#include <QLineEdit>
#include <QFileDialog>
#include <QTableView>
#include <QFile>
#include <QTextStream>
#include <QStandardItemModel>
#include <QHeaderView>

main_s::main_s(QWidget *parent)
    : QWidget{parent}
{
    setWindowTitle("Students--信息");
    setWindowIcon(QIcon(":/icons/C:/Users/admin/Pictures/c.jpg"));
    setMaximumSize(640, 616);
    QString eg = "在文件中编写格式形如：学号,学生,班级,语文,数学,英语(表头)"
                 "112233,张三,八年级七班,80,70,60";
    QString eg2 = "双击编辑可单元格 必须打开文件才可以进行编写 在记事本编写各个数据用英文逗号隔开";
    Eg = new QLabel(eg, this);
    Eg2 = new QLabel(eg2, this);
    QHBoxLayout *hbo = new QHBoxLayout;
    hbo->addWidget(Eg); hbo->addWidget(Eg2);

    table = new QTableView(this);
    table->setEditTriggers(QTableView::AllEditTriggers);
    QHBoxLayout *hbox = new QHBoxLayout;
    hbox->addWidget(table);

    Read = new QPushButton("读取", this);
    Add = new QPushButton("添加", this);
    Save = new QPushButton("保存", this);
    Clear = new QPushButton("清除", this);
    Delete = new QPushButton("删除", this);
    Return = new QPushButton("返回", this);
    Close = new QPushButton("关闭", this);
    QHBoxLayout *hbox2 = new QHBoxLayout;
    hbox2->addWidget(Read); hbox2->addWidget(Add); hbox2->addWidget(Save);
    hbox2->addWidget(Clear); hbox2->addWidget(Delete); hbox2->addWidget(Return); hbox2->addWidget(Close);

    QVBoxLayout *vbox = new QVBoxLayout;
    vbox->addLayout(hbox); vbox->addLayout(hbox2); vbox->addLayout(hbo);

    setLayout(vbox);

    connect(Close, SIGNAL(clicked(bool)), this, SLOT(close()));
    connect(Return, SIGNAL(clicked(bool)), this, SLOT(returns()));
    connect(Read, SIGNAL(clicked(bool)), this, SLOT(ReadFileData()));
    connect(Clear, SIGNAL(clicked(bool)), this, SLOT(clears()));
    connect(Save, SIGNAL(clicked(bool)), this, SLOT(saves()));
    connect(Add, SIGNAL(clicked(bool)), this, SLOT(add()));
    connect(Delete, SIGNAL(clicked(bool)), this, SLOT(deletes()));
}

void main_s::returns()
{
    this->close();
    s_mainWin *ret = new s_mainWin;
    ret->show();
}

void main_s::ReadFileData()
{
    QString filename = QFileDialog::getOpenFileName(this, tr("选择文件"), QDir::homePath(), tr("文本文件 (*.txt)"));
    if (filename.isEmpty()) {
        QMessageBox::information(this, tr("提示"), tr("未选择文件，操作已取消"));
        return;
    }

    QFile file(filename);
    if(!file.open(QIODevice::ReadOnly)){
        qDebug()<< "打开失败";
        QMessageBox::warning(this, QString("警告"), "打开失败");
    }else{
        // QMessageBox::information(this, QString("提示"), "打开成功");
        qDebug()<< "打开成功";
    }

    QStandardItemModel *models = qobject_cast<QStandardItemModel *>(table->model());
    if (models) {
        models->clear();
    }

    //表头
    QTextStream stream(&file);
    QStandardItemModel *model = new QStandardItemModel(this);
    QStringList header = stream.readLine().split(",");
    model->setHorizontalHeaderLabels(header);
    table->setModel(model);
    //data
    while (!stream.atEnd()){
        QStringList Data = stream.readLine().split(",");
        QList<QStandardItem*> items;
        for(QString datas : Data){
            items.push_back(new (QStandardItem)(datas));
        }
        model->appendRow(items);
    }
    file.close();
}

void main_s::clears()
{
    QStandardItemModel *models = qobject_cast<QStandardItemModel *>(table->model());
    if (models) {
        models->clear();
    }
}

void main_s::saves()
{
    QString filename = QFileDialog::getSaveFileName(this, tr("保存文件"), "", tr("文本文件 (*.txt);;所有文件 (*.*)"));
    if (filename.isEmpty()) {
        return; // 用户取消操作
    }

    QFile file(filename);
    if (!file.open(QIODevice::WriteOnly | QIODevice::Text)) {
        qDebug() << "保存失败: " << file.errorString();
        QMessageBox::warning(this, tr("警告"), tr("文件保存失败: ") + file.errorString());
        return;
    }

    QTextStream stream(&file);
    QStandardItemModel *model = qobject_cast<QStandardItemModel *>(table->model());
    if (model) {
        // 写入表头
        QStringList headerLabels;
        for (int i = 0; i < model->columnCount(); ++i) {
            QStandardItem *item = model->horizontalHeaderItem(i);
            headerLabels.append(item ? item->text() : ""); // 将 QStandardItem* 转换为 QString
        }
        stream << headerLabels.join(",") << Qt::endl;
        // 写入数据
        for (int row = 0; row < model->rowCount(); ++row) {
            for (int column = 0; column < model->columnCount(); ++column) {
                QStandardItem *item = model->item(row, column);
                stream << (item ? item->text() : "");
                if (column < model->columnCount() - 1) {
                    stream << ",";
                }
            }
            stream << Qt::endl;
        }
    }

    file.close();
    qDebug() << "保存成功";
    QMessageBox::information(this, tr("提示"), tr("文件保存成功"));
}

void main_s::add()
{
    QStandardItemModel *model = qobject_cast<QStandardItemModel *>(table->model());
    if (!model) {
        QMessageBox::warning(this, tr("警告"), tr("表格模型未正确设置"));
        return;
    }

    // 确定新行的列数与表头一致
    int columnCount = model->columnCount();
    if (columnCount == 0) {
        QMessageBox::warning(this, tr("警告"), tr("表格没有列头 无法添加数据"));
        return;
    }

    // 插入1行
    model->insertRow(model->rowCount());

    // 为新行的每个单元格添加可编辑的项
    for (int column = 0; column < columnCount; ++column) {
        QStandardItem *item = new QStandardItem;
        model->setItem(model->rowCount() - 1, column, item);
    }

    // 选择新添加的行的第一个单元格，以便用户可以直接开始输入
    QModelIndex firstCell = model->index(model->rowCount() - 1, 0);
    table->setCurrentIndex(firstCell);
    table->edit(firstCell);
}

void main_s::deletes()
{
    QStandardItemModel *model = qobject_cast<QStandardItemModel *>(table->model());
    if (!model) {
        QMessageBox::warning(this, tr("警告"), tr("表格模型未正确设置"));
        return;
    }

    // 获取选中的行索引列表
    QModelIndexList selectedRows = table->selectionModel()->selectedIndexes();
    // 根据行号排序选中的行，从大到小，以避免删除后影响行号
    QList<int> rowsToRemove;
    for (QModelIndex index : selectedRows) {
        if (index.isValid() && index.row() != -1) {
            rowsToRemove.append(index.row());
        }
    }
    // 从大到小排序行号，以避免在删除时影响其他行号
    std::sort(rowsToRemove.begin(), rowsToRemove.end(), std::greater<int>());

    // 遍历并删除行
    for (int row : rowsToRemove) {
        model->removeRow(row);
    }
}
