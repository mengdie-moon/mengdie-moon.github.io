#ifndef DIALOG_H
#define DIALOG_H
#include <QDialog>

class QLabel;
class QLineEdit;
class QPushButton;
class QCheckBox;

class Dialog : public QDialog
{
    Q_OBJECT
private:
    QLabel *User;
    QLineEdit *UserInput;

    QLabel *Passworld;
    QLineEdit *PassworldInput;

    QCheckBox *Litter;

    QPushButton *Login;
    QPushButton *termbutton;
    QPushButton *Close;

private slots:
    void login();
public:
    Dialog(QWidget *parent = nullptr);
    ~Dialog();

};
#endif // DIALOG_H
