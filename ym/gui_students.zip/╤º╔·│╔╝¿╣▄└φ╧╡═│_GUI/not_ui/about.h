#ifndef ABOUT_H
#define ABOUT_H

#include <QWidget>

class QLabel;
class QPushButton;

class About : public QWidget
{
    Q_OBJECT
public:
    explicit About(QWidget *parent = nullptr);

private:
    QLabel *writer;
    QLabel *Includece;
    QLabel *add_we;
    QPushButton *url;
    QPushButton *FH;
protected slots:
    void FH_tos();
signals:
};

#endif // ABOUT_H
