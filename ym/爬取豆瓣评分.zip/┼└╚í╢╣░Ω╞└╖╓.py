from lxml import etree
import requests
from fake_useragent import UserAgent


k = str(input("请输入要爬取的网址："))
class DouBanTop250:
    base_url = k
    headers = {
        'User-Agent': UserAgent().random
    }
    def __init__(self):
        self.url_list = []
        for i in range(10):
            url = self.base_url.format(i*25)
            self.url_list.append(url)

    def get_data(self, url):
        data = ''
        response = requests.get(url=url, headers=self.headers)
        html = etree.HTML(response.content.decode())
        data_list = html.xpath("//ol/li")
        for li in data_list:
            title = li.xpath(".//span[@class='title'][1]/text()")
            score = li.xpath(".//span[@class='rating_num'][1]/text()")
            people = li.xpath(".//div[@class='star']/span[last()]/text()")
            quote = li.xpath(".//span[@class='inq'][1]/text()")
            if title and score and people:
                quote_text = "暂无" if not quote or not quote[0].strip() else quote[0]
                score_float = float(score[0])
                f = ('推荐观看') if score_float >= 8.5 else ('不推荐观看')
                data += (f"电影中文名:{title[0]}, 评分人数:{people[0]}, 评分:{score[0]}, 个签:{quote_text}  \n{f}!!!\n")
            else:
                print("Not found")
        with open("豆瓣Top250.txt", 'a', encoding='utf-8') as f:
            f.write(data)

    def run(self):
        for url in self.url_list:
            print(f"正在爬取'{url}'这个页面的数据.." )
            self.get_data(url)
        print(len(self.url_list))

if __name__ == '__main__':
    db = DouBanTop250()
    db.run()


