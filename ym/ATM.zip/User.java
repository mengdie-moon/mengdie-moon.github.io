package com.moon;

public class User {
    private String User_Name;
    private int User_Age;
    private double User_Money;
    private String User_PassWord;
    private String User_Card;
    private double limit;

    public User(String user_Name, int user_Age, double user_Money, String user_PassWord, String user_Card, double limit) {
        User_Name = user_Name;
        User_Age = user_Age;
        User_Money = user_Money;
        User_PassWord = user_PassWord;
        User_Card = user_Card;
        this.limit = limit;
    }

    public User() {
    }

    public void Change_Password(String new_password){
        User_PassWord = new_password;
    }

    public void Change_Money(double changeMoney){
        User_Money += changeMoney;
    }

    public void get_Money(double getsMoney){
        User_Money -= getsMoney;
    }

    public String getUser_Name() {
        return User_Name;
    }

    public void setUser_Name(String user_Name) {
        User_Name = user_Name;
    }

    public int getUser_Age() {
        return User_Age;
    }

    public void setUser_Age(int user_Age) {
        User_Age = user_Age;
    }

    public double getUser_Money() {
        return User_Money;
    }

    public void setUser_Money(double user_Money) {
        User_Money = user_Money;
    }

    public String getUser_PassWord() {
        return User_PassWord;
    }

    public void setUser_PassWord(String user_PassWord) {
        User_PassWord = user_PassWord;
    }

    public String getUser_Card() {
        return User_Card;
    }

    public void setUser_Card(String user_Card) {
        User_Card = user_Card;
    }

    public double getLimit() {
        return limit;
    }

    public void setLimit(double limit) {
        this.limit = limit;
    }
}
