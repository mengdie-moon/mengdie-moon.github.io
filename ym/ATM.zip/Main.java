package com.moon;

public class Main {
    public static void main(String[] args) {
        ComeTrue comeTrue = new ComeTrue();
        comeTrue.Bank_Menu();
    }
}
