package com.moon;

import java.util.ArrayList;
import java.util.Random;
import java.util.Scanner;

public class ComeTrue {
    private ArrayList<User> user = new ArrayList<>();
    private Scanner cin = new Scanner(System.in);
    private Random random = new Random();
    private User Touser = new User();
    //菜单
    public void Bank_Menu(){
        while(true){
            System.out.println("----ATM系统----");
            System.out.println("1. 登录");
            System.out.println("2. 开户");
            System.out.println("3. 退出");
            System.out.print("请选择-->");
            int user_choise = cin.nextInt();
            switch (user_choise){
                case 1:
                    Login();
                    break;
                case 2:
                    Bank_Make();
                    break;
                case 3:
                    System.out.println("欢迎下次光临");
                    System.exit(0);
                default:
                    System.out.println("非法代码~");
            }
        }
    }
    public void Bank_Menu_Two(){
        while(true){
            System.out.println("----管理界面----");
            System.out.println("1. 取款");
            System.out.println("2. 存款");
            System.out.println("3. 转账");
            System.out.println("4. 密码修改");
            System.out.println("5. 个人信息");
            System.out.println("6. 注销账户");
            System.out.println("7. 退出系统");
            System.out.println("8. 返回登录");
            System.out.print("请选择-->");
            int user_choise = cin.nextInt();
            switch (user_choise){
                case 1:
                    getMoney();
                    break;
                case 2:
                    SaveMoney();
                    break;
                case 3:
                    giveOtherMoney();
                    break;
                case 4:
                    Change_Password();
                    break;
                case 5:
                    User_Info();
                    break;
                case 6:
                    Kill_User();
                    break;
                case 7:
                    System.out.println("欢迎下次光临");
                    System.exit(0);
                case 8:
                    Bank_Menu();
                default:
                    System.out.println("非法代码~");
            }
        }
    }
    public void giveOtherMoney(){
        if(user.size() <= 1){
            System.out.println("用户不足两人..!");
            Bank_Menu_Two();
        }
        String othername = "";
        System.out.print("转账人: ");
        othername = cin.next();
        User userss = getUser_names(othername);
        if(userss != null){
            while (true) {
                System.out.print("转入金额: ");
                double money = 0.0;
                money = cin.nextDouble();
                if(money > Touser.getUser_Money()){
                    System.out.println("余额不足");
                    break;
                }
                if(money > Touser.getLimit()){
                    System.out.println("Error: 超过额度");
                    continue;
                }else{
                    Touser.get_Money(money);
                    userss.Change_Money(money);
                    System.out.println("转账成功");
                    break;
                }
            }
        }else{
            System.out.println("转账人不存在");
            Bank_Menu_Two();
        }
    }
    public void getMoney(){
        double getsMoney = 0.0;
        System.out.println(Touser.getUser_Name() + " 当前余额: " + Touser.getUser_Money());
        while(true) {
            System.out.print("取款金额: ");
            getsMoney = cin.nextDouble();
            if(getsMoney > Touser.getUser_Money()){
                System.out.println("Error: 余额不足!!");
                continue;
            }else{
                Touser.get_Money(getsMoney);
                System.out.println("取款成功");
                break;
            }
        }
        System.out.println(Touser.getUser_Name() + " 取款金额: " + getsMoney);
        System.out.println(Touser.getUser_Name() + " 当前余额: " + Touser.getUser_Money());
    }
    public void SaveMoney(){
        System.out.println(Touser.getUser_Name() + " 当前余额: " + Touser.getUser_Money());
        while(true) {
            System.out.print("存款金额: ");
            double addMoney = 0.0;
            addMoney = cin.nextDouble();
            if (addMoney > Touser.getLimit()){
                System.out.println("Error: 请勿超过额度!!");
                continue;
            }else{
                Touser.Change_Money(addMoney);
                System.out.println("存入成功");
                break;
            }
        }
        System.out.println(Touser.getUser_Name() + " 当前余额: " + Touser.getUser_Money());
    }
    public void Change_Password(){
        System.out.print("原密码: ");
        String befor_password = cin.next();
        if(befor_password.equals(Touser.getUser_PassWord())){
            System.out.print("修改后密码:");
            String new_password = cin.next();
            Touser.Change_Password(new_password);
            System.out.println("修改成功");
        }else {
            System.out.println("密码错误");
            Bank_Menu_Two();
        }
    }
    public void Kill_User(){
        user.remove(Touser);
        System.out.println("注销成功!");
        Bank_Menu();
    }
    public void User_Info(){
        System.out.println("用户名: " + Touser.getUser_Name());
        System.out.println("用户年龄: " + Touser.getUser_Age());
        System.out.println("用户额度: " + Touser.getLimit());
        System.out.println("用户卡号: " + Touser.getUser_Card());
        System.out.println("用户余额: " + Touser.getUser_Money());
    }
    public boolean Bank_Login_If(){
        if(user.isEmpty()){
            System.out.println("没有创建过账户哦~");
            return false;
        }
        return true;
    }
    public void Login(){
        boolean ok = true;
        if(!Bank_Login_If()){Bank_Menu();}
        String user_card = "";
        String password = "";
        System.out.print("请输入卡号: ");
        user_card = cin.next();
        User user2 = getUser_CardId(user_card);
        if(user2 == null){
            System.out.println("无此卡号");
            Bank_Menu();
        }else {
            while(true){
                System.out.print("密码: ");
                password = cin.next();
                System.out.println(user2.getUser_PassWord().equals(password));
                if(user2.getUser_PassWord().equals(password)){
                    Touser = user2;
                    System.out.println("欢迎" + user2.getUser_Name() + "登录ATM");
                    break;
                }else {
                    System.out.println("密码错误");
                    continue;
                }
            }
            Bank_Menu_Two();
        }
    }
    public void Bank_Make(){
        User user2 = new User();
        System.out.print("用户名: ");
        String user_name = cin.next();
        user2.setUser_Name(user_name);
        while(true){
            System.out.print("密码:");
            String password = cin.next();
            System.out.print("确认密码:");
            String okpassword = cin.next();
            if(okpassword.equals(password)){
                user2.setUser_PassWord(password);
                break;
            }else {
                System.out.println("密码不对");
                continue;
            }
        }
        int user_age = 0;
        while(true){
            System.out.print("持卡人年龄: ");
            user_age = cin.nextInt();
            if(user_age<16){
                System.out.println("持卡人年龄不满16周岁");
                continue;
            }else{break;}
        }
        user2.setUser_Age(user_age);
        System.out.print("最大额度:");
        double limit = cin.nextDouble();
        user2.setLimit(limit);
        String card_number = "0123456789";
        String user_card = "";
        for (int i = 0; i < 6; i++) {
            int index = random.nextInt(card_number.length());
            user_card += card_number.charAt(index);//不考虑重复卡号
        }
        user2.setUser_Card(user_card);
        System.out.println("你的6位卡号已经生成: " + user_card + "\n开户成功");
        user.add(user2);
        System.out.println("数据添加成功");
        Bank_Menu();
    }
    public User getUser_CardId(String user_card){
        for(int i=0;i < user.size();i++){
            User users = user.get(i);
            if(users.getUser_Card().equals(user_card)){
                return users;
            }
        }
        return null;
    }
    public User getUser_names(String user_name){
        for(int i=0;i < user.size();i++){
            User users = user.get(i);
            if(users.getUser_Name().equals(user_name)){
                return users;
            }
        }
        return null;
    }
}
